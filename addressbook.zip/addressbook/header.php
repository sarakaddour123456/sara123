<!DOCTYPE html>
<html>
<head>
	<title>Address book | Welcome</title>
	<!-- include bootstrap css -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<!-- include bootstrap js -->
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<!-- include my style -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- include my js -->
	<script type="text/javascript" src="js/custom.js"></script>
</head>
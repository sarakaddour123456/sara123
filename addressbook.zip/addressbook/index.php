<?php
include"header.php";
include"navbar.php";
?>
<!-- start image -->
<div class="container a">
	<img src="images/add.png" style="width: 490px; height: 490px;">
</div>
<!-- end image -->
<?php
include"footer.php";
?>
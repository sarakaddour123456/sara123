<!-- start footer -->
	<div class="footer text-center">
		<p>All Right Reversed  reem@addressbook
		 </p>
	</div>
<!-- end footer -->
</body>
</html>